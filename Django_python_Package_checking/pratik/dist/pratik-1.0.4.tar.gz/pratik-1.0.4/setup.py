from setuptools import *#importing all the files from the setup file
setup(name="pratik",
      version="1.0.4",description="This is my own package for the addition",
      long_description="Just for checking purpose",
      packages=["com"],
      author="Pratik K Sarangi",
      author_email="psarangi50@gmail.com")
