from setuptools import *#importing all the files from the setup file
setup(name="package_pratik",
      version="1.0.2",description="This is my own package for the addition",
      long_description="Just for checking purpose",
      packages=["packagepratik"],
      install_requires=["time"],
      author="Pratik K Sarangi",
      author_email="psarangi50@gmail.com")
