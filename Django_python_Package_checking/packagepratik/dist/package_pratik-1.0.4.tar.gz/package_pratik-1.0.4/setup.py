from setuptools import *#importing all the files from the setup file
setup(name="package_pratik",
      version="1.0.4",description="This is my own package for the addition",
      long_description="Just for checking purpose",
      packages=["package_pratik"],
      author="Pratik K Sarangi",
      author_email="psarangi50@gmail.com")
