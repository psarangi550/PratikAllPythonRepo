import time
def add(a,b):#defining the function with arguments
    time.sleep(3)#sleeping for 3 seconds
    print(f"The addition is {a+b} value")#printing the value to the console
    
